var mensagem="Sejam bem vindos!";
alert(mensagem);

function mudaFoto (foto)
{
document.getElementById("color").src=foto;	
}

function validarForm () {
if(document.getElementById('caixa').value==""){
alert("Este campo deve ser preenchido");
document.getElementById('caixa').focus();
return false;
}
}

function validarForm () {
if(document.getElementById('pass').value==""){
alert("Este campo deve ser preenchido");
document.getElementById('pass').focus();
return false;
}
} 


function limpa() {
if(document.getElementById('caixa').value!="") {
document.getElementById('pass').value="";
document.getElementById('documento').value="";
document.getElementById('endeletronico').value="";
alert("Seu formulário está limpo!");
}
}
