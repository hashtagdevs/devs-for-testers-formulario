alert('estrutura');

console.log('teste', document.getElementById('123').innerHTML);

console.log(document.getElementsByTagName('p')[0].innerHTML);

console.log(document.getElementsByTagName('p')[1].innerHTML);


var c = document.getElementsByTagName('p')[1];

console.log('c',c);


var x = 1;

console.log(x);

var array = [1, 2, 3];

console.log(array);

var abc = document.getElementsByClassName('classe')[1].value;

console.log(abc);