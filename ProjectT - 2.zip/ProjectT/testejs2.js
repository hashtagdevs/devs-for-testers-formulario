function mudaFoto (foto)
{
	document.getElementById("color").src=foto;	
}