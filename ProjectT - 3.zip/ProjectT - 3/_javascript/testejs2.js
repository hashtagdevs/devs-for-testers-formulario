<script> 
	var mensagem="Socorro!" + " " + "JS é difícil sim!";
	alert(mensagem);
</script>


function mudaFoto (foto)
{
	document.getElementById("color").src=foto;
	
}


function mudaFoto (foto)
{
	document.getElementById("carol").src=foto;
	
}







function validar () {
	if(document.fcadastro.usuario.value==""){
		alert("Este campo deve ser preenchido");
		document.fcadastro.usuario.focus();
		return false;
			}
	}
	
	function validar () {
	if(document.fcadastro.pass.value==""){
		alert("campo senha não pode estar vazio");
		document.fcadastro.pass.focus();
		return false;
			}
	}
	
	function validar () {
	if(document.fcadastro.documento.value==""){
		alert("O CPF deve ser informado.");
		document.fcadastro.documento.focus();
		return false;
			}
	}
	
	function validar () {
	if(document.fcadastro.endeletronico.value==""){
		alert("Informe seu e-mail");
		document.fcadastro.endeletronico.focus();
		return false;
			}
	}
	
	
			