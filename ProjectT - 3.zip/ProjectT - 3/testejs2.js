	var mensagem="Socorro!" + " " + "JS é difícil sim!";
	alert(mensagem);

	function mudaFoto (foto)
	{
		document.getElementById("color").src=foto;	
	}

	function validarForm () {
		if(document.getElementById('caixa').value==""){
			alert("Este campo deve ser preenchido");
			document.getElementById('caixa').focus();
			return false;
		}
	}
	
	
			